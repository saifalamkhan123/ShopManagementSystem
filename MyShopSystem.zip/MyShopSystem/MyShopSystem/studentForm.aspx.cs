﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;



namespace MyShopSystem
{
    public partial class studentForm : System.Web.UI.Page
    {
        string cs = ConfigurationManager.ConnectionStrings["dbcs"].ConnectionString;

        protected void Page_Load(object sender, EventArgs e)
        {

            bindGrid();
            insertLabel.Visible = false;
            errorLabel.Visible = false;
            checkRecordLabel.Visible = false;
          

        }

        public void bindGrid()
        {
            SqlConnection con = new SqlConnection(cs);
            con.Open();
            string query = "select * from student";
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            GridView1.DataSource = dt;
            GridView1.DataBind();

        }

        protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "Select")
            {

                int id = Convert.ToInt32(e.CommandArgument);


                string selectQuery = "SELECT * FROM student WHERE student_id = @student_id";
                SqlConnection con = new SqlConnection(cs);
                SqlCommand cmd = new SqlCommand(selectQuery, con);
                
                    cmd.Parameters.AddWithValue("@student_id", id);
                    con.Open();
                    SqlDataReader reader = cmd.ExecuteReader();
                    if (reader.Read())
                    {

                        id_TextBox.Text = reader["student_id"].ToString();
                        nameTextBox.Text = reader["student_name"].ToString();
                    }
                    reader.Close();
                
            }
        }

        protected void addButton_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(cs);

            string query = "select count(*) from student where student_name = @student_name";

            SqlCommand cmdValidation = new SqlCommand(query,con);

            cmdValidation.Parameters.AddWithValue("@student_name", nameTextBox.Text);

            con.Open();

            int countRecord = (int)cmdValidation.ExecuteScalar();
            

            try
            {
                if (string.IsNullOrEmpty(nameTextBox.Text))
                {

                    errorLabel.Visible = true;

                }

                else if (countRecord > 0)
                {

                    checkRecordLabel.Visible = true;

                }

                else
                {

                   
                    SqlCommand cmd = con.CreateCommand();
                    string query1 = $"insert into student values ('{nameTextBox.Text.ToString()}')";
                    cmd.CommandText = query1;


                    cmd.ExecuteNonQuery();
                    //insertLabel.Visible = true;


                    ScriptManager.RegisterStartupScript(this, GetType(), "Popup", "insertMessage();", true);

                  
                    nameTextBox.Text = "";
                    id_TextBox.Text = "";
                    con.Close();
                    bindGrid();

                }
                                   
                
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);

            }

        }

        protected void updateButton_Click(object sender, EventArgs e)
        {
            updateButton.OnClientClick = "return updateMessage();";
           
            try
            {

                    SqlConnection con = new SqlConnection(cs);
                    con.Open();
                    SqlCommand cmd = con.CreateCommand();
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandText = "update student set student_name='" + nameTextBox.Text + "' where student_id='" + id_TextBox.Text + "'";
                    cmd.ExecuteNonQuery();

                    nameTextBox.Text = "";
                    id_TextBox.Text = "";
                    bindGrid();
                    con.Close();
                
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);

            }

        }

        protected void deleteButton_Click(object sender, EventArgs e)
        {
            deleteButton.OnClientClick = "return confirmDelete();";

            try
            {
                                
                SqlConnection con = new SqlConnection(cs);
                con.Open();
                SqlCommand cmd = con.CreateCommand();
                string query = $"delete student where student_id='{id_TextBox.Text.ToString()}'";
                cmd.CommandText = query;

               cmd.ExecuteNonQuery();
                GridView1.DataSource = query;
                ScriptManager.RegisterStartupScript(this, GetType(), "Popup", "successDelete();", true);

                nameTextBox.Text = "";
                id_TextBox.Text = "";
                bindGrid();
                con.Close();
            }

            catch (Exception ex)
            {
                Response.Write(ex.Message);

            }

        }

        protected void refreshButton_Click(object sender, EventArgs e)
        {
            //id_TextBox.Text = "";
            //nameTextBox.Text = "";
            Response.Redirect("studentForm.aspx");

        }

       
    }
}