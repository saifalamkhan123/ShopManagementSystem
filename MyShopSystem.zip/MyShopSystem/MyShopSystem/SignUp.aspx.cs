﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;

namespace MyShopSystem
{
    public partial class SignUp : System.Web.UI.Page
    {

        string cs = ConfigurationManager.ConnectionStrings["dbcs"].ConnectionString;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {

                bindCountryDDL();

            }

        }

        void resetControl()
        {
            FnameTextBox.Text = "";
            LnameTextBox.Text = "";
            BirthTextBox.Text = "";
            GenderTextBox.Text = "";
            EmailTextBox.Text = "";
            PhoneTextBox.Text = "";
            UserTextBox.Text = "";
            PasswordTextBox.Text = "";
            CountryDropDownList.ClearSelection();
            CityDropDownList.ClearSelection();

        }

        void bindCountryDDL()
        {
            SqlConnection con = new SqlConnection(cs);
            string query = "select * from country_tbl";
            SqlCommand cmd = new SqlCommand(query, con);
            
            SqlDataAdapter da = new SqlDataAdapter();
            da.SelectCommand = cmd;
            DataTable dt = new DataTable();
            da.Fill(dt);
            CountryDropDownList.DataSource = dt;
            CountryDropDownList.DataTextField = "country";
            CountryDropDownList.DataValueField = "id";

            CountryDropDownList.DataBind();

            ListItem selectItem = new ListItem("Select Country", "Select Country");
            selectItem.Selected = true;
            CountryDropDownList.Items.Insert(0, "Select Country");

        }


        void bindCityDDL(int country_id)
        {
            SqlConnection con = new SqlConnection(cs);
            string query = "select * from city_tbl where c_id=@country_id";
            
            SqlDataAdapter da = new SqlDataAdapter(query,con);

            da.SelectCommand.Parameters.AddWithValue("@country_id", country_id);
           
            DataTable dt = new DataTable();
            da.Fill(dt);
            CityDropDownList.DataSource = dt;
            CityDropDownList.DataTextField = "city";
            CityDropDownList.DataValueField = "id";

            CityDropDownList.DataBind();

            ListItem selectItem = new ListItem("Select City", "Select City");
            selectItem.Selected = true;
            CityDropDownList.Items.Insert(0, "Select City");

        }



        protected void submitButton_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(cs);

            try
            {

                string query = "insert into signup_tbl values (@firstname, @lastname, @birthday, @gender, @email, @phonenumber, @username, @password, @country, @city)";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@firstname", FnameTextBox.Text);
                cmd.Parameters.AddWithValue("@lastname", LnameTextBox.Text);
                cmd.Parameters.AddWithValue("@birthday", BirthTextBox.Text);
                cmd.Parameters.AddWithValue("@gender", GenderTextBox.Text);
                cmd.Parameters.AddWithValue("@email", EmailTextBox.Text);
                cmd.Parameters.AddWithValue("@phonenumber", PhoneTextBox.Text);
                cmd.Parameters.AddWithValue("@username", UserTextBox.Text);
                cmd.Parameters.AddWithValue("@password", PasswordTextBox.Text);
                cmd.Parameters.AddWithValue("@country", CountryDropDownList.SelectedItem.ToString());
                cmd.Parameters.AddWithValue("@city", CityDropDownList.SelectedItem.ToString());
                con.Open();

                int a = cmd.ExecuteNonQuery();

                if (a > 0)
                {

                    //Response.Write("<script>alert('You have registered successfully')</script>");

                    ScriptManager.RegisterStartupScript(this, this.GetType(), "popup", "Swal.fire( 'Success','You have registered successfully', 'success' )", true);

                    resetControl();

                }

                else
                {


                    ScriptManager.RegisterStartupScript(this, this.GetType(), "popup", "Swal.fire( 'Failed','Registration failed !!!!', 'error' )", true);
                    //Response.Write("<script>alert('Insertion failed...')</script>");


                }

            }

            catch (SqlException ex)
            {

                if (ex.Message.Contains("UNIQUE KEY constraint"))
                {

                    ScriptManager.RegisterStartupScript(this, this.GetType(), "popup", "Swal.fire( 'Failure','"+UserTextBox.Text+" Already Exist', 'error' )", true);

                }
                else
                {

                    ScriptManager.RegisterStartupScript(this, this.GetType(), "popup", "Swal.fire( 'Failure','Operation failed !!!!', 'error' )", true);

                }
            }

            finally {
                con.Close();
            }
            


        }

        protected void CountryDropDownList_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                int country_id = Convert.ToInt32(CountryDropDownList.SelectedValue.ToString());
                bindCityDDL(country_id);
            }
            catch(Exception ex)
            {

                ScriptManager.RegisterStartupScript(this, this.GetType(), "popup", "Swal.fire( 'Failure','Country is required..', 'error' )", true);


            }
        }
    }
}