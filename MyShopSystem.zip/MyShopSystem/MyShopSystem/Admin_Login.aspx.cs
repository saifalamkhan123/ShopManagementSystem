﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;


namespace MyShopSystem
{
    public partial class Admin_Login : System.Web.UI.Page
    {
        string cs = ConfigurationManager.ConnectionStrings["dbcs"].ConnectionString;

        protected void Page_Load(object sender, EventArgs e)
        {


        }

        protected void SubmitButton_Click(object sender, EventArgs e)
        {

            SqlConnection con = new SqlConnection(cs);
            string query = "select * from adminLogin_tbl where username = @username and password = @password";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@username", NameTextBox.Text);
            cmd.Parameters.AddWithValue("@password", PasswordTextBox.Text);
            con.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.HasRows == true)
            {
                Session["admin_username"] = NameTextBox.Text;
                Response.Redirect("~/admin/Admin_Index.aspx");

            }
            else
            {
                //  Response.Write("<script>alert('User name and Password is incorrect!!!!')</script>");

                ScriptManager.RegisterStartupScript(this, this.GetType(), "popup", "Swal.fire( 'Error','User name and Password is incorrect !!!!', 'error' )", true);

            }

            con.Close();

        }
    }
}