﻿using System;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;



namespace MyShopSystem.sales_man
{
    public partial class saleEntry : System.Web.UI.Page
    {

        string cs = ConfigurationManager.ConnectionStrings["dbcs"].ConnectionString;

        protected void Page_Load(object sender, EventArgs e)
        {

            if (Session["sales_username"] == null)
            {
                Response.Redirect("~/salesman_Login.aspx");

            }


            dateTextBox.Text = DateTime.Now.ToString("yyyy-MM-dd");


            bindGrid();
            showId();
            GrandTotal();


            if (!IsPostBack)
            {

                bindCategoryDDL();
                bindStockDDL();



            }


        }




        public void getRate()
        {


            int rateId = Convert.ToInt32(stockDropDownList.SelectedValue);
            string rate = "";


            using (SqlConnection connection = new SqlConnection(cs))
            {
                string query = "select rate from stock_tbl where stock_id= @stock_id";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@stock_id", rateId);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    rate = reader["rate"].ToString();
                }
                reader.Close();
            }


            rateTextBox.Text = rate.ToString();


        }



        public void getStock()
        {


            int stockId = Convert.ToInt32(stockDropDownList.SelectedValue);
            string quantity = "";


            using (SqlConnection connection = new SqlConnection(cs))
            {
                string query = "select quantity from stock_tbl where stock_id= @stock_id";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@stock_id", stockId);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    quantity = reader["quantity"].ToString();
                }
                reader.Close();
            }


            stockQuantityTextBox.Text = quantity.ToString();


        }



        public void bindStockDDL()
        {



            SqlConnection con = new SqlConnection(cs);
            con.Open();
            string query = "select * from stock_tbl";

            SqlCommand cmd = new SqlCommand(query, con);


            SqlDataAdapter da = new SqlDataAdapter(cmd);



            DataTable dt = new DataTable();
            da.Fill(dt);


            stockDropDownList.DataSource = dt;
            stockDropDownList.DataValueField = "stock_id";
            stockDropDownList.DataTextField = "stock_name";

            stockDropDownList.DataBind();
            ListItem selectItem = new ListItem("stock", "Select Stock");
            selectItem.Selected = true;
            stockDropDownList.Items.Insert(0, "Select Stock Item");
        }





        public void bindCategoryDDL()
        {
            SqlConnection con = new SqlConnection(cs);
            con.Open();
            string query = "select * from category_tbl";
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);


            DataTable dt = new DataTable();
            da.Fill(dt);


            categoryDDL.DataSource = dt;
            categoryDDL.DataValueField = "id";
            categoryDDL.DataTextField = "category";

            categoryDDL.DataBind();
            ListItem selectItem = new ListItem("category", "Select Category");
            selectItem.Selected = true;
            categoryDDL.Items.Insert(0, "Select Category");

        }



        private void showId()
        {
            SqlConnection con = new SqlConnection(cs);
            con.Open();
            SqlCommand cmd = new SqlCommand("SELECT MAX(sale_id) + 1 as Id FROM sale_tbl", con);
            idTextBox.Text = cmd.ExecuteScalar().ToString();
            con.Close();
        }


        public void bindGrid()
        {
            SqlConnection con = new SqlConnection(cs);
            con.Open();

            string query = "select * from sale_tbl";
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            GridView1.DataSource = dt;
            GridView1.DataBind();

        }


        public void bindImage()
        {
            SqlConnection con = new SqlConnection(cs);
            con.Open();
            string query = "select stock_img from stock_tbl where category_id = '" + categoryDDL.SelectedValue + "'";

            SqlDataAdapter da = new SqlDataAdapter(query, con);
            DataTable dt = new DataTable();
            da.Fill(dt);
            stockImage.ImageUrl = dt.Rows[0]["stock_img"].ToString();
        }

        protected void stockDropDownList_SelectedIndexChanged(object sender, EventArgs e)
        {

            try
            {

                bindImage();
                getStock();
                getRate();
                int quantity = 1;


                quantityTextBox.Text = quantity.ToString();
                int rate = Convert.ToInt32(rateTextBox.Text);


                totalAmountTextBox.Text = (rate * quantity).ToString();


            }
            catch
            {

                Response.Write("<script>alert('Please select stock as per Category Item...')</script>");

            }

        }

        protected void quantityTextBox_TextChanged(object sender, EventArgs e)
        {

            try
            {

                int quantity = Convert.ToInt32(quantityTextBox.Text);
                int rate = Convert.ToInt32(rateTextBox.Text);
                int stockQuantity = Convert.ToInt32(stockQuantityTextBox.Text);

                int totalStockQuantity = stockQuantity - quantity;

                int total = quantity * rate;

                totalAmountTextBox.Text = total.ToString();
                stockQuantityTextBox.Text = totalStockQuantity.ToString();
            }
            catch(Exception ex)
            {

                Response.Redirect(ex.Message);
            }

        }

        protected void saveButton_Click(object sender, EventArgs e)
        {

            try
            {

                SqlConnection con = new SqlConnection(cs);
                con.Open();
                SqlCommand cmd = con.CreateCommand();

                cmd.CommandType = CommandType.Text;
                cmd.CommandText = $"insert into sale_tbl values ('{idTextBox.Text.ToString()}', '{dateTextBox.Text.ToString()}', " +
                    $"'{customerTextBox.Text.ToString()}', '{categoryDDL.SelectedItem.ToString()}', '{stockDropDownList.SelectedItem.ToString()}', " +
                    $"'{rateTextBox.Text.ToString()}', " +
                    $"'{quantityTextBox.Text.ToString()}', '{totalAmountTextBox.Text.ToString()}',  '{stockImage.ImageUrl.ToString()}')";

                SqlCommand updateCmd = con.CreateCommand();
                updateCmd.CommandType = CommandType.Text;
                updateCmd.CommandText = $"update stock_tbl set quantity = '" + stockQuantityTextBox.Text + "' where category_id = '" + categoryDDL.SelectedValue + "'";


                int a = cmd.ExecuteNonQuery();
                int b = updateCmd.ExecuteNonQuery();

                if (a > 0 || b > 0)
                {
                    Response.Write("<script>alert('Record inserted successfully')</script>");
                    bindGrid();
                    GrandTotal();
                }


                con.Close();

            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);

            }


        }


        private void GrandTotal()
        {


            float GTotal = 0f;
            for (int i = 0; i < GridView1.Rows.Count; i++)
            {
                String total = (GridView1.Rows[i].FindControl("quantityTotalLabel") as Label).Text;
                GTotal += Convert.ToSingle(total);
            }
            totalSaleTextBox.Text = GTotal.ToString();


        }

        protected void refreshButton_Click(object sender, EventArgs e)
        {

            Response.Redirect("saleEntry.aspx");

            GrandTotal();

        }
    }
}