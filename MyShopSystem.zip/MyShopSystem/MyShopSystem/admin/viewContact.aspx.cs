﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;

namespace MyShopSystem.admin
{
    public partial class viewContact : System.Web.UI.Page
    {

        string cs = ConfigurationManager.ConnectionStrings["dbcs"].ConnectionString;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["admin_username"] == null)
            {
                Response.Redirect("Admin_Login.aspx");

            }

            if (!IsPostBack)
            {
                bindGrid();

            }

        }

        void bindGrid()
        {

            SqlConnection con = new SqlConnection(cs);
            string query = "select * from contact_tbl";
            SqlDataAdapter da = new SqlDataAdapter(query,con);
            DataTable dt = new DataTable();
            da.Fill(dt);
            GridView1.DataSource = dt;
            GridView1.DataBind();

        }

        protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            GridViewRow row = GridView1.Rows[e.RowIndex];
            Label itemId = (Label)row.FindControl("labelId");
            string id = itemId.Text;
            SqlConnection con = new SqlConnection(cs);
            string query = "delete from contact_tbl where id = @id";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@id", id);
            con.Open();
            int a = cmd.ExecuteNonQuery();
            if (a > 0)
            {

                Response.Write("<script>alert('Record has been deleted...')</script>");
                bindGrid();

            }
            con.Close();
        }

        void bindSearchGrid()
        {

            SqlConnection con = new SqlConnection(cs);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            string query = "select * from contact_tbl where name like '%'+@name+'%' or subject like '%'+@subject+'%' ";
           cmd.CommandText = query;
            cmd.Connection = con;
            cmd.Parameters.AddWithValue("@name",SearchText.Text);
            cmd.Parameters.AddWithValue("@subject", SearchText.Text);
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            GridView1.DataSource = dt;
            GridView1.DataBind();

        }

        protected void searchBtn_ServerClick(object sender, EventArgs e)
        {
            
            bindSearchGrid();

        }
    }
}