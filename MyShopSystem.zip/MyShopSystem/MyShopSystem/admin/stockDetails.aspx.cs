﻿using System;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;


namespace MyShopSystem.admin
{
    public partial class stockDetails : System.Web.UI.Page
    {
        string cs = ConfigurationManager.ConnectionStrings["dbcs"].ConnectionString;

        protected void Page_Load(object sender, EventArgs e)
        {

            if (Session["admin_username"]==null)
            {

                Response.Redirect("~/Admin_Login.aspx");

            }

            idTextBox.ReadOnly = true;

            bindGrid();

            if (!IsPostBack)
            {

                bindDDL();

            }


        }

        public void bindGrid()
        {
            SqlConnection con = new SqlConnection(cs);
            con.Open();
            string query = "select * from stock_tbl";
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            GridView1.DataSource = dt;
            GridView1.DataBind();

        }

        public void bindDDL()
        {
            SqlConnection con = new SqlConnection(cs);
            con.Open();
            string query = "select * from category_tbl";
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);


            categoryDDL.DataSource = dt;
            categoryDDL.DataValueField = "id";
            categoryDDL.DataTextField = "category";

            categoryDDL.DataBind();

        }

        protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
        {


            if (e.CommandName == "Select")
            {

                int id = Convert.ToInt32(e.CommandArgument);



                string selectQuery = "SELECT * FROM stock_tbl WHERE stock_id = @stock_id";
                SqlConnection con = new SqlConnection(cs);
                SqlCommand cmd = new SqlCommand(selectQuery, con);

                cmd.Parameters.AddWithValue("@stock_id", id);

                con.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {

                    idTextBox.Text = reader["stock_id"].ToString();
                    stockNameTextBox.Text = reader["stock_name"].ToString();


                    categoryDDL.SelectedValue = reader["category_id"].ToString();


                    rateTextBox.Text = reader["rate"].ToString();
                    quantityTextBox.Text = reader["quantity"].ToString();
                }
                reader.Close();

            }
        }

        protected void addButton_Click(object sender, EventArgs e)
        {
            try
            {


                if (FileUpload1.HasFile)
                {
                    string str = FileUpload1.FileName;
                    FileUpload1.PostedFile.SaveAs(Server.MapPath("~/Upload/" + str));
                    string Image = "~/Upload/" + str.ToString();
                    string stockName = stockNameTextBox.Text;
                    string category = categoryDDL.SelectedValue;
                    string rate = rateTextBox.Text;
                    string quantity = quantityTextBox.Text;


                    SqlConnection con = new SqlConnection(cs);
                    SqlCommand cmd = new SqlCommand("insert into stock_tbl values (@stock_name, @category_id, @rate, @quantity, @stock_img)", con);
                    cmd.Parameters.AddWithValue("@stock_name", stockName);
                    cmd.Parameters.AddWithValue("@category_id", category);
                    cmd.Parameters.AddWithValue("@rate", rate);
                    cmd.Parameters.AddWithValue("@quantity", quantity);
                    cmd.Parameters.AddWithValue("@stock_img", Image);

                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();

                    Label1.Text = "Record inserted successfully";
                    Label1.ForeColor = System.Drawing.Color.ForestGreen;
                    bindGrid();

                }

                else
                {
                    Label1.Text = "Please Upload your Image";
                    Label1.ForeColor = System.Drawing.Color.Red;
                }

            }

            catch (Exception ex)
            {
                Response.Write(ex.Message);

            }
        }


        protected void refreshButton_Click(object sender, EventArgs e)
        {

            Response.Redirect("stockDetails.aspx");

        }

        protected void updateButton_Click(object sender, EventArgs e)
        {
            try
            {


                if (FileUpload1.HasFile)
                {
                    string str = FileUpload1.FileName;
                    FileUpload1.PostedFile.SaveAs(Server.MapPath("~/Upload/" + str));
                    string Image = "~/Upload/" + str.ToString();
                    string stockName = stockNameTextBox.Text;
                    string category = categoryDDL.SelectedValue;
                    string rate = rateTextBox.Text;
                    string quantity = quantityTextBox.Text;


                    SqlConnection con = new SqlConnection(cs);
                    SqlCommand cmd = new SqlCommand("update stock_tbl set stock_name='" + stockNameTextBox.Text + "' , category_id = '" + categoryDDL.SelectedValue + "', rate = '" + rateTextBox.Text + "' , quantity = '" + quantityTextBox.Text + "', stock_img = '" + Image + "'   where stock_id='" + idTextBox.Text + "'", con);


                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();

                    Label1.Text = "Record updated successfully";
                    Label1.ForeColor = System.Drawing.Color.ForestGreen;
                    bindGrid();

                }

                else
                {
                    Label1.Text = "Please Upload your Image";
                    Label1.ForeColor = System.Drawing.Color.Red;
                }


            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);

            }
        }

        protected void deleteButton_Click(object sender, EventArgs e)
        {

            try
            {

                SqlConnection con = new SqlConnection(cs);
                con.Open();
                SqlCommand cmd = con.CreateCommand();
                string query = $"delete stock_tbl where stock_id='{idTextBox.Text.ToString()}'";
                cmd.CommandText = query;

                cmd.ExecuteNonQuery();
                GridView1.DataSource = query;
                Label1.Text = "Record deleted successfully";
                Label1.ForeColor = System.Drawing.Color.Red;


                bindGrid();
                con.Close();
            }

            catch (Exception ex)
            {
                Response.Write(ex.Message);

            }



        }
    }
}