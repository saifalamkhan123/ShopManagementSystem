﻿using System;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;



namespace MyShopSystem.admin
{
    public partial class purchaseDetails : System.Web.UI.Page
    {

        string cs = ConfigurationManager.ConnectionStrings["dbcs"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {

         

            if (Session["admin_username"] == null)
            {
                Response.Redirect("~/Admin_Login.aspx");

            }

            dateTextBox.Text = DateTime.Now.ToString("yyyy-MM-dd");

            bindGrid();
            showId();



            if (!IsPostBack)
            {


                bindCategoryDDL();
                bindStockDDL();

            }

        }


        public void getRate()
        {


            int rateId = Convert.ToInt32(stockDropDownList.SelectedValue);
            string rate = "";


            using (SqlConnection connection = new SqlConnection(cs))
            {
                string query = "select rate from stock_tbl where stock_id= @stock_id";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@stock_id", rateId);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    rate = reader["rate"].ToString();
                }
                reader.Close();
            }


            rateTextBox.Text = rate.ToString();


        }



        public void getStock()
        {


            int stockId = Convert.ToInt32(stockDropDownList.SelectedValue);
            string quantity = "";


            using (SqlConnection connection = new SqlConnection(cs))
            {
                string query = "select quantity from stock_tbl where stock_id= @stock_id";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@stock_id", stockId);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    quantity = reader["quantity"].ToString();
                }
                reader.Close();
            }


            stockQuantityTextBox.Text = quantity.ToString();


        }


        private void showId()
        {
            SqlConnection con = new SqlConnection(cs);
            con.Open();
            SqlCommand cmd = new SqlCommand("SELECT MAX(product_id) + 1 as Id FROM purchase_tbl", con);
            idTextBox.Text = cmd.ExecuteScalar().ToString();
            con.Close();
        }



        public void bindStockDDL()
        {



            SqlConnection con = new SqlConnection(cs);
            con.Open();
            string query = "select * from stock_tbl";

            SqlCommand cmd = new SqlCommand(query, con);


            SqlDataAdapter da = new SqlDataAdapter(cmd);



            DataTable dt = new DataTable();
            da.Fill(dt);


            stockDropDownList.DataSource = dt;
            stockDropDownList.DataValueField = "stock_id";
            stockDropDownList.DataTextField = "stock_name";

            stockDropDownList.DataBind();
            ListItem selectItem = new ListItem("stock", "Select Stock");
            selectItem.Selected = true;
            stockDropDownList.Items.Insert(0, "Select Stock Item");
        }





        public void bindCategoryDDL()
        {
            SqlConnection con = new SqlConnection(cs);
            con.Open();
            string query = "select * from category_tbl";
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);


            DataTable dt = new DataTable();
            da.Fill(dt);


            categoryDDL.DataSource = dt;
            categoryDDL.DataValueField = "id";
            categoryDDL.DataTextField = "category";

            categoryDDL.DataBind();
            ListItem selectItem = new ListItem("category", "Select Category");
            selectItem.Selected = true;
            categoryDDL.Items.Insert(0, "Select Category");

        }


        public void bindGrid()
        {
            SqlConnection con = new SqlConnection(cs);
            con.Open();
            string query = "select * from purchase_tbl";
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            GridView1.DataSource = dt;
            GridView1.DataBind();

        }

        protected void refreshButton_Click(object sender, EventArgs e)
        {

            Response.Redirect("purchaseDetails.aspx");

        }

        protected void saveButton_Click(object sender, EventArgs e)
        {

            try
            {

                SqlConnection con = new SqlConnection(cs);
                con.Open();
                SqlCommand cmd = con.CreateCommand();

                cmd.CommandType = CommandType.Text;
                cmd.CommandText = $"insert into purchase_tbl values ('{idTextBox.Text.ToString()}', '{dateTextBox.Text.ToString()}', " +
                    $"'{vendorTextBox.Text.ToString()}', '{categoryDDL.SelectedItem.ToString()}', '{stockDropDownList.SelectedItem.ToString()}', " +
                    $"'{rateTextBox.Text.ToString()}', " +
                    $"'{quantityTextBox.Text.ToString()}', '{totalAmountTextBox.Text.ToString()}')";

                SqlCommand updateCmd = con.CreateCommand();
                updateCmd.CommandType = CommandType.Text;
                updateCmd.CommandText = $"update stock_tbl set quantity = '" + stockQuantityTextBox.Text + "' where category_id = '" + categoryDDL.SelectedValue + "'";


                int a = cmd.ExecuteNonQuery();
                int b = updateCmd.ExecuteNonQuery();

                if (a > 0 || b > 0)
                {
                    Response.Write("<script>alert('Record inserted successfully')</script>");
                    bindGrid();
                }


                con.Close();

            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);

            }


        }

        protected void stockDropDownList_SelectedIndexChanged(object sender, EventArgs e)
        {

            try
            {

                getStock();
                getRate();
                int quantity = 1;


                quantityTextBox.Text = quantity.ToString();
                int rate = Convert.ToInt32(rateTextBox.Text);


                totalAmountTextBox.Text = (rate * quantity).ToString();


            }
            catch
            {

                Response.Write("<script>alert('Please select stock as per Category Item...')</script>");

            }



        }

        protected void quantityTextBox_TextChanged(object sender, EventArgs e)
        {

            try
            {

                int quantity = Convert.ToInt32(quantityTextBox.Text);
                int rate = Convert.ToInt32(rateTextBox.Text);
                int stockQuantity = Convert.ToInt32(stockQuantityTextBox.Text);

                int totalStockQuantity = quantity + stockQuantity;

                int total = quantity * rate;

                totalAmountTextBox.Text = total.ToString();
                stockQuantityTextBox.Text = totalStockQuantity.ToString();
            }

            catch (Exception ex)
            {
                Response.Write(ex.Message);

            }


        }
    }
}